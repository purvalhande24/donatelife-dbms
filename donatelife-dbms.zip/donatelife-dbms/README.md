# 🩸 DonateLife - Donation Management System

A Java Swing desktop application for managing donations, donors, campaigns, and payments — built as a DBMS project using **Java + MySQL (JDBC)**.

---

## 📋 Features

- **Admin Panel** — Full dashboard with donation stats and recent activity
- **Donor Management** — Add, view, and manage donors (monetary, blood, organ)
- **Campaign Management** — Create and track donation campaigns
- **Donation Tracking** — Record and monitor individual donations
- **Payment Processing** — Log payments with transaction references
- **User Dashboard** — Donor-facing view of their history
- **Login System** — Separate admin and user login flows

---

## 🛠️ Tech Stack

| Layer       | Technology           |
|-------------|----------------------|
| Language    | Java (JDK 8+)        |
| UI          | Java Swing           |
| Database    | MySQL 8.x            |
| Connectivity| JDBC (mysql-connector-j) |
| IDE         | NetBeans             |

---

## 🗄️ Database Schema

Tables: `admin`, `donor`, `campaign`, `beneficiary`, `donation`, `payment`

See [`sql/donation_db.sql`](sql/donation_db.sql) for the full schema and setup script.

---

## 🚀 Setup & Running

### Prerequisites
- JDK 8 or higher
- MySQL 8.x server running locally
- NetBeans IDE (or any Java IDE)
- [MySQL Connector/J JAR](https://dev.mysql.com/downloads/connector/j/)

### Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/donatelife-dbms.git
   cd donatelife-dbms
   ```

2. **Set up the database**
   ```bash
   mysql -u root -p < sql/donation_db.sql
   ```

3. **Configure DB credentials**

   Open `src/DBConnection.java` and update:
   ```java
   private static final String URL  = "jdbc:mysql://localhost:3306/donation_db";
   private static final String USER = "root";
   private static final String PASS = "your_password_here"; // ← change this
   ```

   Or set the environment variable `DB_PASSWORD` before running.

4. **Open in NetBeans**
   - File → Open Project → select this folder
   - Right-click project → Properties → Libraries → Add JAR → select `mysql-connector-j-x.x.x.jar`

5. **Run**
   - Right-click project → Run  
   - Or press `F6`

---

## 📁 Project Structure

```
donatelife-dbms/
├── src/
│   ├── donationsystem/
│   │   └── DonationSystem.java     # Main entry point
│   ├── DBConnection.java           # MySQL JDBC connection helper
│   ├── LandingPage.java            # App landing/welcome screen
│   ├── LoginPage.java              # User login
│   ├── LoginForm.java              # Admin login form
│   ├── MainDashboard.java          # Admin dashboard (stats + nav)
│   ├── UserDashboard.java          # Donor-facing dashboard
│   ├── DonorForm.java              # Add/manage donors
│   ├── DonationForm.java           # Record donations
│   ├── CampaignForm.java           # Campaign management
│   └── PaymentForm.java            # Payment logging
├── sql/
│   └── donation_db.sql             # Full DB schema + sample data
├── nbproject/                      # NetBeans project config
├── build.xml                       # Ant build file
├── manifest.mf
└── README.md
```

---

## 🔒 Security Note

> **Do not commit your real database password.**  
> The `DBConnection.java` file reads from the `DB_PASSWORD` environment variable first.  
> Set it before running:
> ```bash
> # Linux / macOS
> export DB_PASSWORD=your_actual_password
>
> # Windows (cmd)
> set DB_PASSWORD=your_actual_password
> ```

---

## 📸 Screenshots

<!-- Add screenshots here once available -->
_Coming soon_

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.

---

## 📄 License

This project was developed as a DBMS course project.
